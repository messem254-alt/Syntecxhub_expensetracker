import { Link, useNavigate } from "react-router-dom";

export default function Sidebar() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  const logout = () => {
    localStorage.clear();
    navigate("/login");
    window.location.reload();
  };

  const linkStyle = {
    display: "block",
    padding: "50px 50px",
    marginBottom: "10px",
    textDecoration: "none",
    color: "#333",
    borderRadius: "8px",
    fontWeight: "500",
    backgroundColor: "#fff",
    boxShadow: "0 2px 6px rgba(0,0,0,0.08)",
  };

  return (
    <div
      style={{
        width: "240px",
        minHeight: "100vh",
        background: "linear-gradient(180deg, #e3f2fd, #f4f6f8)",
        padding: "20px",
        boxShadow: "4px 0 10px rgba(0,0,0,0.1)",
        fontFamily: "Arial, sans-serif",
      }}
    >
      {/* User Info */}
      <div
        style={{
          marginBottom: "30px",
          textAlign: "center",
          padding: "15px",
          backgroundColor: "#fff",
          borderRadius: "12px",
          boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
        }}
      >
        <div
          style={{
            width: "80px",
            height: "80px",
            margin: "0 auto 20px",
            borderRadius: "50%",
            backgroundColor: "#4CAF50",
            color: "#fff",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "22px",
            fontWeight: "bold",
          }}
        >
          {user?.username?.charAt(0).toUpperCase()}
        </div>

        <h3 style={{ margin: 0, color: "#333" }}>
          {user?.username || "User"}
        </h3>
      </div>

      {/* Navigation Links */}
      <Link to="/" style={linkStyle}>🏠 Dashboard</Link>
      <Link to="/accounts" style={linkStyle}>📊 Accounts</Link>
      <Link to="/transactions" style={linkStyle}>💸 Transactions</Link>
      <Link to="/budget" style={linkStyle}>📒 Budget</Link>
      <Link to="/analytics" style={linkStyle}>📊 Analytics</Link>
      <Link to="/profile" style={linkStyle}>👤 Profile</Link>

      {/* Logout */}
      <button
        onClick={logout}
        style={{
          width: "100%",
          marginTop: "50px",
          padding: "30px",
          backgroundColor: "#f44336",
          color: "#fff",
          border: "none",
          borderRadius: "8px",
          fontSize: "15px",
          cursor: "pointer",
          boxShadow: "0 4px 10px rgba(0,0,0,0.15)",
        }}
      >
        Logout
      </button>
    </div>
  );
}
