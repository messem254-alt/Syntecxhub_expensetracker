export default function Navbar() {
  return (
    <div
      style={{
        height: "60px",
        background: "linear-gradient(90deg, #0e141bff, #030d14ff)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "0 25px",
        color: "#fff",
        boxShadow: "0 4px 10px rgba(0,0,0,0.15)",
        position: "sticky",
        top: 0,
        zIndex: 1000,
        fontFamily: "Arial, sans-serif"
      }}
    >
      {/* App Title */}
      <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
        <div
          style={{
            width: "40px",
            height: "40px",
            borderRadius: "50%",
            background: "#c5c1c1ff",
            color: "#0a0d11ff",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "20px",
            fontWeight: "bold"
          }}
        >
          💰
        </div>

        <h2 style={{ margin: 0, fontSize: "20px", fontWeight: "600" }}>
          Personal Finance Tracker
        </h2>
      </div>

      {/* Right Section (future use) */}
      <span style={{ fontSize: "14px", opacity: 0.9 }}>
        Track • Save • Grow
      </span>
    </div>
  );
}
