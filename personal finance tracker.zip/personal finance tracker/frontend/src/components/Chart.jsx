import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer
} from "recharts";

const data = [
  { month: "Jan", income: 0, expense: 0},
  { month: "Feb", income: 4500, expense: 1500 },
  { month: "Mar", income: 2800, expense: 1000 },
  { month: "Apr", income: 5000, expense: 1800 },
  { month: "May", income: 4200, expense: 1600 },
  { month: "Jun", income: 5500, expense: 2000 }
];

export default function Chart() {
  return (
    <div
      style={{
        background: "#ffffff",
        padding: "20px",
        borderRadius: "12px",
        boxShadow: "0 6px 15px rgba(0,0,0,0.1)",
        marginTop: "20px",
        
      }}
    >
      <h3 style={{ textAlign: "center", marginBottom: "15px", color: "#333" }}>
        Monthly Income vs Expense
      </h3>

      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="month" />
          <YAxis />
          <Tooltip />

          <Line
            type="monotone"
            dataKey="income"
            stroke="#2e7d32"
            
            strokeWidth={3}
            dot={{ r: 4 }}
          />

          <Line
            type="monotone"
            dataKey="expense"
            stroke="#c62828"
            strokeWidth={3}
            dot={{ r: 4 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

