import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useState } from "react";

import Sidebar from "./components/Sidebar";
import Navbar from "./components/Navbar";

import Dashboard from "./pages/Dashboard";
import Accounts from "./pages/Accounts";
import Transactions from "./pages/Transactions";
import Budget from "./pages/Budget";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Profile from "./pages/Profile";
import Analytics from "./pages/Analytics";

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <BrowserRouter>

      {!isLoggedIn ? (
        // 🔒 BEFORE LOGIN
        <Routes>
          <Route path="/login" element={<Login setIsLoggedIn={setIsLoggedIn} />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="*" element={<Navigate to="/login" />} />
        </Routes>
      ) : (
        // 🔓 AFTER LOGIN
        <>
          <Navbar />
          <div style={{ display: "flex" }}>
            <Sidebar />
            <div style={{ padding: "20px", width: "100%" }}>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/accounts" element={<Accounts />} />
                <Route path="/transactions" element={<Transactions />} />
                <Route path="/budget" element={<Budget />} />
                <Route path="*" element={<Navigate to="/" />} />
                <Route path="/Analytics" element={<Analytics />} />
                <Route path="/profile" element={<Profile />} />


                

              </Routes>
            </div>
          </div>
        </>
      )}

    </BrowserRouter>
  );
}
