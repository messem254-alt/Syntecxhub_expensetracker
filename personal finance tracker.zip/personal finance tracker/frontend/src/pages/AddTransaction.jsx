import api from "../api";
import { useState } from "react";

export default function AddTransaction() {
  const [data,setData] = useState({ title:"", amount:"", type:"income", date:"" });

  const add = async () => {
    await api.post("/transaction/add", data);
    alert("Added");
  };

  return (
    <div>
      <input placeholder="Title" onChange={e=>setData({...data,title:e.target.value})}/>
      <input placeholder="Amount" onChange={e=>setData({...data,amount:e.target.value})}/>
      <select onChange={e=>setData({...data,type:e.target.value})}>
        <option value="income">Income</option>
        <option value="expense">Expense</option>
      </select>
      <input type="date" onChange={e=>setData({...data,date:e.target.value})}/>
      <button onClick={add}>Add</button>
    </div>
  );
}
