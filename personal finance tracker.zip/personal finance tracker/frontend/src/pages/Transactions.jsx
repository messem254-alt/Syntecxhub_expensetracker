import axios from "axios";
import { useEffect, useState } from "react";

export default function Transactions() {
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const [type, setType] = useState("income");
  const [list, setList] = useState([]);

  const fetchData = async () => {
    const res = await axios.get("http://localhost:5000/api/transactions");
    setList(res.data);
  };

  const addTx = async () => {
    await axios.post("http://localhost:5000/api/transactions", {
      title,
      amount,
      type,
    });
    setTitle("");
    setAmount("");
    setType("income");
    fetchData();
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div
      style={{
        minHeight: "100vh",
        backgroundColor: "#f4f6f8",
        padding: "30px",
        fontFamily: "Arial, sans-serif",
      }}
    >
      {/* Add Transaction Card */}
      <div
        style={{
          maxWidth: "500px",
          margin: "0 auto",
          backgroundColor: "#fff",
          padding: "25px",
          borderRadius: "12px",
          boxShadow: "0 8px 20px rgba(0,0,0,0.15)",
        }}
      >
        <h2 style={{ textAlign: "center", color: "#333" }}>
          Add Transaction
        </h2>

        <input
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          style={{
            width: "100%",
            padding: "10px",
            marginTop: "15px",
            borderRadius: "6px",
            border: "1px solid #ccc",
          }}
        />

        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          style={{
            width: "100%",
            padding: "10px",
            marginTop: "10px",
            borderRadius: "6px",
            border: "1px solid #ccc",
          }}
        />

        <select
          value={type}
          onChange={(e) => setType(e.target.value)}
          style={{
            width: "100%",
            padding: "10px",
            marginTop: "10px",
            borderRadius: "6px",
            border: "1px solid #ccc",
          }}
        >
          <option value="income">Income</option>
          <option value="expense">Expense</option>
        </select>

        <button
          onClick={addTx}
          style={{
            width: "100%",
            marginTop: "20px",
            padding: "10px",
            backgroundColor: "#4CAF50",
            color: "#fff",
            border: "none",
            borderRadius: "6px",
            fontSize: "16px",
            cursor: "pointer",
          }}
        >
          Add Transaction
        </button>
      </div>

      {/* Transaction List */}
      <div
        style={{
          maxWidth: "600px",
          margin: "30px auto",
          backgroundColor: "#fff",
          padding: "20px",
          borderRadius: "12px",
          boxShadow: "0 6px 15px rgba(0,0,0,0.1)",
        }}
      >
        <h3 style={{ textAlign: "center", color: "#333" }}>
          Transaction List
        </h3>

        <ul style={{ listStyle: "none", padding: 0, marginTop: "20px" }}>
          {list.map((tx) => (
            <li
              key={tx._id}
              style={{
                display: "flex",
                justifyContent: "space-between",
                padding: "10px",
                marginBottom: "10px",
                backgroundColor: tx.type === "income" ? "#e8f5e9" : "#fdecea",
                borderRadius: "6px",
                color: "#333",
              }}
            >
              <span>{tx.title}</span>
              <span>
                {tx.amount} ({tx.type})
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
