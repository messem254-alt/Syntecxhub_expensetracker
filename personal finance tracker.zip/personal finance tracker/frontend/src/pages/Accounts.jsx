import axios from "axios";
import { useEffect, useState } from "react";

export default function Accounts() {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const res = await axios.get("http://localhost:5000/api/transactions");
      setTransactions(res.data);
      setLoading(false);
    };
    fetchData();
  }, []);

  if (loading) {
    return (
      <h3 style={{ textAlign: "center", marginTop: "50px" }}>
        Loading accounts data...
      </h3>
    );
  }

  let income = 0;
  let expense = 0;

  transactions.forEach((tx) => {
    if (tx.type === "income") income += Number(tx.amount);
    else if (tx.type === "expense") expense += Number(tx.amount);
  });

  const balance = income - expense;

  return (
    <div
      style={{
        minHeight: "100vh",
        backgroundColor: "#f4f6f8",
        padding: "30px",
        fontFamily: "Arial, sans-serif",
      }}
    >
      <h1 style={{ textAlign: "center", color: "#333", marginBottom: "30px" }}>
        Accounts Summary
      </h1>

      <div
        style={{
          maxWidth: "500px",
          margin: "0 auto",
          backgroundColor: "#fff",
          padding: "25px",
          borderRadius: "12px",
          boxShadow: "0 8px 20px rgba(0,0,0,0.15)",
        }}
      >
        <p style={{ fontSize: "16px", marginBottom: "10px" }}>
          <b>Total Transactions:</b> {transactions.length}
        </p>

        <p style={{ fontSize: "16px", marginBottom: "10px" }}>
          <b>Total Income:</b>{" "}
          <span style={{ color: "green" }}>Rs. {income}</span>
        </p>

        <p style={{ fontSize: "16px", marginBottom: "10px" }}>
          <b>Total Expense:</b>{" "}
          <span style={{ color: "red" }}>Rs. {expense}</span>
        </p>

        <hr style={{ margin: "20px 0" }} />

        <p style={{ fontSize: "18px", marginBottom: "10px" }}>
          <b>Current Balance:</b>{" "}
          <span style={{ color: balance >= 0 ? "green" : "red" }}>
            Rs. {balance}
          </span>
        </p>

        <p
          style={{
            fontSize: "16px",
            fontWeight: "bold",
            color: balance >= 0 ? "green" : "red",
          }}
        >
          Status: {balance >= 0 ? "Saving / Profit 👍" : "Loss ⚠️"}
        </p>
      </div>
    </div>
  );
}
