import { useEffect, useState } from "react";
import axios from "axios";

export default function AdvancedAnalytics() {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const res = await axios.get("http://localhost:5000/api/transactions");
      setTransactions(res.data);
      setLoading(false);
    };
    fetchData();
  }, []);

  if (loading) return <h3 style={{textAlign:"center", marginTop:"50px"}}>Loading analytics...</h3>;

  // Calculations
  const totalIncome = transactions.filter(tx=>tx.type==="income").reduce((sum, tx)=>sum+Number(tx.amount),0);
  const totalExpense = transactions.filter(tx=>tx.type==="expense").reduce((sum, tx)=>sum+Number(tx.amount),0);
  const balance = totalIncome - totalExpense;
  const avgIncome = totalIncome / 6;  // assuming 6 months data
  const avgExpense = totalExpense / 6;

  const highestIncome = transactions.filter(tx=>tx.type==="income").reduce((max, tx)=> Number(tx.amount) > max ? Number(tx.amount) : max , 0);
  const highestExpense = transactions.filter(tx=>tx.type==="expense").reduce((max, tx)=> Number(tx.amount) > max ? Number(tx.amount) : max , 0);

  const savingsRate = totalIncome ? ((balance / totalIncome) * 100).toFixed(2) : 0;

  return (
    <div style={{minHeight:"100vh", background:"#f4f6f8", padding:"30px", fontFamily:"Arial, sans-serif"}}>
      <h1 style={{textAlign:"center"}}>📊 Advanced Analytics</h1>

      <div style={{display:"flex", flexWrap:"wrap", gap:"20px", justifyContent:"center", marginTop:"20px"}}>
        <div style={{flex:"1 1 200px", background:"#fff", padding:"20px", borderRadius:"12px", boxShadow:"0 6px 15px rgba(0,0,0,0.1)", textAlign:"center"}}>
          <h3>Average Monthly Income</h3>
          <p style={{color:"green", fontSize:"20px"}}>Rs. {avgIncome.toFixed(2)}</p>
        </div>

        <div style={{flex:"1 1 200px", background:"#fff", padding:"20px", borderRadius:"12px", boxShadow:"0 6px 15px rgba(0,0,0,0.1)", textAlign:"center"}}>
          <h3>Average Monthly Expense</h3>
          <p style={{color:"red", fontSize:"20px"}}>Rs. {avgExpense.toFixed(2)}</p>
        </div>

        <div style={{flex:"1 1 200px", background:"#fff", padding:"20px", borderRadius:"12px", boxShadow:"0 6px 15px rgba(0,0,0,0.1)", textAlign:"center"}}>
          <h3>Highest Income</h3>
          <p style={{color:"green", fontSize:"20px"}}>Rs. {highestIncome}</p>
        </div>

        <div style={{flex:"1 1 200px", background:"#fff", padding:"20px", borderRadius:"12px", boxShadow:"0 6px 15px rgba(0,0,0,0.1)", textAlign:"center"}}>
          <h3>Highest Expense</h3>
          <p style={{color:"red", fontSize:"20px"}}>Rs. {highestExpense}</p>
        </div>

        <div style={{flex:"1 1 200px", background:"#fff", padding:"20px", borderRadius:"12px", boxShadow:"0 6px 15px rgba(0,0,0,0.1)", textAlign:"center"}}>
          <h3>Savings Rate</h3>
          <p style={{color: balance>=0 ? "green":"red", fontSize:"20px"}}>{savingsRate} %</p>
        </div>
      </div>
    </div>
  );
}
