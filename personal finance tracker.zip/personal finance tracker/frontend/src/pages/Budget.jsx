import React, { useState, useEffect } from "react";
import axios from "axios";

const Budget = () => {
  const [budgets, setBudgets] = useState([]);
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");

  // Fetch budgets on load
  useEffect(() => {
    const fetchBudgets = async () => {
      try {
        const res = await axios.get("http://localhost:5000/budgets");
        setBudgets(res.data);
      } catch (err) {
        console.error("Failed to fetch budgets:", err);
      }
    };
    fetchBudgets();
  }, []);

  // Add new budget
  const addBudget = async (e) => {
    e.preventDefault();
    if (!title || !amount) return;

    try {
      const res = await axios.post("http://localhost:5000/budgets", {
        title,
        amount: parseFloat(amount),
      });
      setBudgets([...budgets, res.data]);
      setTitle("");
      setAmount("");
    } catch (err) {
      console.error("Failed to add budget:", err);
    }
  };

  // Clear all budgets
 const clearBudgets = async () => {
  try {
    await axios.delete("http://localhost:5000/budgets/clear"); // backend endpoint
    setBudgets([]); // frontend state bhi clear
  } catch (err) {
    console.error("Failed to clear budgets:", err);
  }
};


  return (
    <div
      style={{
        maxWidth: "500px",
        margin: "40px auto",
        padding: "20px",
        backgroundColor: "#f7f7f7",
        borderRadius: "10px",
        boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
        fontFamily: "Arial, sans-serif",
      }}
    >
      

      <h2 style={{ marginTop: "20px", color: "#555" }}>Add New Budget</h2>
      <form
        onSubmit={addBudget}
        style={{ display: "flex", gap: "10px", marginBottom: "20px" }}
      >
        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          style={{
            flex: "2",
            padding: "8px",
            borderRadius: "5px",
            border: "1px solid #ccc",
          }}
        />
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          style={{
            flex: "1",
            padding: "8px",
            borderRadius: "5px",
            border: "1px solid #ccc",
          }}
        />
        <button
          type="submit"
          style={{
            padding: "8px 12px",
            border: "none",
            borderRadius: "5px",
            backgroundColor: "#4caf50",
            color: "white",
            cursor: "pointer",
          }}
        >
          Add
        </button>
      </form>

      {budgets.length > 0 && (
        <div>
          <h2 style={{ color: "#555" }}>Your Budgets</h2>
          <ul style={{ listStyleType: "none", padding: 0 }}>
            {budgets.map((b, index) => (
              <li
                key={index}
                style={{
                  backgroundColor: "#fff",
                  marginBottom: "10px",
                  padding: "10px",
                  borderRadius: "5px",
                  display: "flex",
                  justifyContent: "space-between",
                  boxShadow: "0 2px 5px rgba(0,0,0,0.05)",
                }}
              >
                <span>{b.title}</span>
                <span>{b.amount.toFixed(2)}</span>
              </li>
            ))}
          </ul>
          <button
            onClick={clearBudgets}
            style={{
              marginTop: "10px",
              padding: "8px 12px",
              border: "none",
              borderRadius: "5px",
              backgroundColor: "#f44336",
              color: "white",
              cursor: "pointer",
            }}
          >
            Clear All Budgets
          </button>
        </div>
      )}
    </div>
  );
};

export default Budget;
