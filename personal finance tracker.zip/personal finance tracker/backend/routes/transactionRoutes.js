import express from "express";
import Transaction from "../models/Transaction.js";

const router = express.Router();

router.post("/", async (req,res)=>{
  const tx = new Transaction(req.body);
  await tx.save();
  res.json(tx);
});

router.get("/", async (req,res)=>{
  const data = await Transaction.find();
  res.json(data);
});

export default router;
