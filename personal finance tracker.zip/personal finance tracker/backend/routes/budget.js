// routes/budget.js
import express from "express";
import Budget from "../models/Budget.js";
const router = express.Router();

// Add budget
router.post("/", async (req, res) => {
  try {
    const budget = new Budget(req.body);
    await budget.save();
    res.status(201).json(budget);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get all budgets
router.get("/", async (req, res) => {
  try {
    const budgets = await Budget.find();
    res.json(budgets);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.delete("/clear", async (req, res) => {
  console.log("🔥 CLEAR BUDGET API HIT");   // <<< ye line
  try {
    await Budget.deleteMany({});
    res.json({ message: "All budgets cleared!" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});



export default router;
