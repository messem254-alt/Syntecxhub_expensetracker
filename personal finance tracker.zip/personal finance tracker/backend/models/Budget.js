// models/Budget.js
import mongoose from "mongoose";

const budgetSchema = new mongoose.Schema({
  title: String,
  amount: Number,
});

const Budget = mongoose.model("Budget", budgetSchema);
export default Budget;
