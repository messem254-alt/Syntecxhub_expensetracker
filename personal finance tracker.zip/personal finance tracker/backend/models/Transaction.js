import mongoose from "mongoose";

const transactionSchema = new mongoose.Schema({
  title: String,
  amount: Number,
  type: String, // income / expense
  date: { type: Date, default: Date.now }
});

export default mongoose.model("Transaction", transactionSchema);
