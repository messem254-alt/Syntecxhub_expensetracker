import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import transactionRoutes from "./routes/transactionRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import budgetRoutes from "./routes/budget.js";

const app = express();
app.use(cors());
app.use(express.json());
app.use("/api/auth", authRoutes);
app.use("/budgets", budgetRoutes);

mongoose.connect("mongodb://127.0.0.1:27017/financeDB")
.then(()=>console.log("MongoDB Connected"))
.catch(err=>console.log(err));

app.use("/api/transactions", transactionRoutes);

app.listen(5000, ()=> {
  console.log("Server running on port 5000");
});
